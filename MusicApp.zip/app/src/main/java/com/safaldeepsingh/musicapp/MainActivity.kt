package com.safaldeepsingh.musicapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.safaldeepsingh.musicapp.entities.DiscogResponse
import com.safaldeepsingh.musicapp.network.DiscogApi
import com.safaldeepsingh.musicapp.adapter.AlbumAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private val albumAdapter = AlbumAdapter(context = this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchEditText: EditText = findViewById(R.id.main_searchString)
        val searchButton: Button = findViewById(R.id.main_search)
        val openFavourites: Button = findViewById(R.id.main_openFavourites)
        val recyclerView = findViewById<RecyclerView>(R.id.main_searchResults)

        recyclerView.adapter = albumAdapter
        recyclerView.setHasFixedSize(true) //Performance: If RecyclerView height and width doesn't change

        searchButton.setOnClickListener {
            val searchString: String = searchEditText.text.toString()
            searchDiscogs(searchString)
        }
        openFavourites.setOnClickListener {
            startActivity(Intent(this, FavouritesListActivity::class.java))
        }
    }
    private fun searchDiscogs(searchString: String) {
        val callAlbums = DiscogApi.RETROFIT_SERVICE.getAlbums(search = searchString)
        callAlbums.enqueue(object: Callback<DiscogResponse>
        {
            override fun onResponse(
                call: Call<DiscogResponse>,
                response: Response<DiscogResponse>
            ) {
                var discogResponse = response.body()
                if(discogResponse != null){
                    albumAdapter.setData(discogResponse.albums)
                    Log.e("main","success")
                }else{
                    Log.e("main","failed")
                }
            }

            override fun onFailure(call: Call<DiscogResponse>, t: Throwable) {
                Log.e("main failure","failed")
                println(t)
            }
        })

    }
}